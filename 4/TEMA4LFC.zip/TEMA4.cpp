#include <iostream>
#include "AFN.h"
int main()
{
	AFN A;
	A.Citire();
	A.Afisare();
	std::cout << "\n";
	if (A.Verificare() == 1)
		std::cout << "AUTOMATUL ESTE OK";
	return 0;
}

